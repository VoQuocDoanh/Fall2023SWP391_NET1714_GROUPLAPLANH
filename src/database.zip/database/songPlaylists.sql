INSERT INTO `song_playlists` (`id`, `created_at`, `name`, `status`, `owner`) VALUES
(1, '2023-10-31 14:25:48.787453', '\"ChristmasPlayList\"', 1, 3);
INSERT INTO `song_playlists` (`id`, `created_at`, `name`, `status`, `owner`) VALUES
(2, '2023-10-31 14:25:48.787453', '\"RandomPlayList\"', 1, 3);
INSERT INTO `song_playlists` (`id`, `created_at`, `name`, `status`, `owner`) VALUES
(3, '2023-10-31 14:25:48.787453', '\"MyTienPlayList\"', 1, 3);
INSERT INTO `song_playlists` (`id`, `created_at`, `name`, `status`, `owner`) VALUES
(4, '2023-10-31 14:25:48.787453', '\"HongHanhPlayList\"', 1, 4),
(5, '2023-10-31 14:25:48.787453', '\"LapLanhPlayList\"', 1, 9);