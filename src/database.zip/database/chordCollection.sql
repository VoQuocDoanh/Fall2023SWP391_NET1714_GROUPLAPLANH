INSERT INTO `chord collection` (`id`, `created_at`, `description`, `name`, `status`, `user_collection`) VALUES
(1, '2023-10-31 14:25:48.787453', '\"Almost chords about C are in this Playlist\"', '\"C Playlist\"', 1, 3);
INSERT INTO `chord collection` (`id`, `created_at`, `description`, `name`, `status`, `user_collection`) VALUES
(2, '2023-10-31 14:25:48.787453', '\"Almost chords about D are in this Playlist\"', '\"D Playlist\"', 1, 3);
INSERT INTO `chord collection` (`id`, `created_at`, `description`, `name`, `status`, `user_collection`) VALUES
(3, '2023-10-31 14:25:48.787453', '\"Almost chords about A are in this Playlist\"', '\"A Playlist\"', 1, 3);
INSERT INTO `chord collection` (`id`, `created_at`, `description`, `name`, `status`, `user_collection`) VALUES
(4, '2023-10-31 14:25:48.787453', '\"Almost chords about B are in this Playlist\"', '\"B Playlist\"', 1, 3),
(5, '2023-10-31 14:25:48.787453', '\"Almost chords about E are in this Playlist\"', '\"E Playlist\"', 1, 3);