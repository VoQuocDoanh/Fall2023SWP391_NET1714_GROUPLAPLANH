INSERT INTO `genre_song` (`song_id`, `genre_id`) VALUES
(11, 2);
INSERT INTO `genre_song` (`song_id`, `genre_id`) VALUES
(12, 7);
INSERT INTO `genre_song` (`song_id`, `genre_id`) VALUES
(15, 3);
INSERT INTO `genre_song` (`song_id`, `genre_id`) VALUES
(15, 8),
(16, 8),
(17, 1),
(18, 3),
(19, 8);