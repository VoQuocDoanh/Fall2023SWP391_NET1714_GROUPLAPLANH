INSERT INTO `musician_information` (`id`, `prize`, `professional`, `year_of_operation`) VALUES
(1, 'Best rookie of 2021', 'Singer, Musician', 5);
INSERT INTO `musician_information` (`id`, `prize`, `professional`, `year_of_operation`) VALUES
(2, 'Best Musician of 2022', 'Guitarist, Musician', 10);