INSERT INTO `chord_in_collection` (`chord_id`, `collecton_id`) VALUES
(19, 1);
INSERT INTO `chord_in_collection` (`chord_id`, `collecton_id`) VALUES
(20, 1);
INSERT INTO `chord_in_collection` (`chord_id`, `collecton_id`) VALUES
(16, 1);
INSERT INTO `chord_in_collection` (`chord_id`, `collecton_id`) VALUES
(17, 1),
(18, 1),
(21, 1),
(22, 1),
(23, 1);