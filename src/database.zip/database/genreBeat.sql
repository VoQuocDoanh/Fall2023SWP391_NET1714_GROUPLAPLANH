INSERT INTO `genre_beat` (`beat_id`, `genre_id`) VALUES
(23, 6);
INSERT INTO `genre_beat` (`beat_id`, `genre_id`) VALUES
(23, 2);
INSERT INTO `genre_beat` (`beat_id`, `genre_id`) VALUES
(24, 1);
INSERT INTO `genre_beat` (`beat_id`, `genre_id`) VALUES
(24, 2),
(25, 1),
(25, 3),
(26, 1),
(27, 7),
(27, 3),
(28, 7),
(28, 1),
(29, 8),
(29, 7),
(30, 3),
(30, 1),
(31, 1),
(31, 6);