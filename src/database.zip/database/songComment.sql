INSERT INTO `song_comment` (`id`, `content`, `created_at`, `user_id`, `parentid`, `song_id`) VALUES
(1, '\"Correct Chords of Song\"', '2023-10-31 14:25:48.787453', 3, NULL, 11);
INSERT INTO `song_comment` (`id`, `content`, `created_at`, `user_id`, `parentid`, `song_id`) VALUES
(2, '\"But I think C is not correct at the begining of verse 1', '2023-10-31 14:25:48.787453', 3, 1, 11);